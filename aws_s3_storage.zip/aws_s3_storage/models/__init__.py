from . import amazon_image_storage
from . import product_template
from . import product_product
from . import res_config_settings
from . import amazon_dashboard
from . import ir_attachment
from . import s3_model_selection_wizard